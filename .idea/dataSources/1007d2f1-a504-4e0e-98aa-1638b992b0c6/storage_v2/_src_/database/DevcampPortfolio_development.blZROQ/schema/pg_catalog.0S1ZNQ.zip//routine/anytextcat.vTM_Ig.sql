create function anytextcat(anynonarray, text)
  returns text
stable
strict
cost 1
language sql
as $$
select $1::pg_catalog.text || $2
$$;

comment on function anytextcat(anynonarray, text)
is 'implementation of || operator';

alter function anytextcat(anynonarray, text)
  owner to postgres;

